﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        static void Main()
        {
            //DairyProducts yogurt = new DairyProducts();
            //object o = yogurt; //upcasting

            //implicit & explicit

            Product portmana = new Product //initialization with properties
            {
                Id = 1,
                Name = "William Polo",
                Price = 250,
                StoreCount = 500,
                Category = "Pulqabi"
            };

            Product mouse = new Product() //initialization with properties
            {
                Id = 2,
                Name = "Hp 4502GX",
                Price = 20,
                StoreCount = 1500,
                Category = "Computer Accessories"
            };

            Client client = new Client
            {
                SerialNumber = "AZE111222",
                Firstname = "Samir",
                Lastname = "Dadash-zade",
                Phone = "+994 55 555 5555"
            };

            Client client2 = new Client
            {
                SerialNumber = "AZE121212",
                Firstname = "Ceyhun",
                Lastname = "Elizade",
                Phone = "+994 55 223 2323"
            };

            Order order1 = new Order(portmana.Id, client.SerialNumber)
            {
                OrderId = 1,
                OrderCount = 1
            };

            Order order2 = new Order(portmana.Id, client2.SerialNumber)
            {
                OrderId = 3,
                OrderCount = 2
            };

            Order order3 = new Order(mouse.Id, client2.SerialNumber, 3);
            order3.OrderId = 3;

        }
    }

    class Order
    {
        public Order(uint productId, string clientId)
        {
            ProductId = productId;
            ClientId = clientId;
            Date = DateTime.Now;
            Console.WriteLine("New order just happened");
        }

        public Order(uint proId, string clId, int count) : this(proId, clId)
        {
            OrderCount = count;
        }

        public int OrderId { get; set; }
        public uint ProductId { get; set; }
        public string ClientId { get; set; }
        public int OrderCount { get; set; }
        public DateTime Date { get; set; }
    }

    class Product
    {
        protected uint _id;
        public uint Id {
            get {
                return _id;
            }
            set {
                if(value > 10000)
                {
                    throw new ArgumentException("Id can not be bigger than 10000");
                }

                _id = value;
            }
        }
        public string Name { get; set; }
        public decimal Price { get; set; }
        public int StoreCount { get; set; }
        public string Category { get; set; }
    }

    class ExpirableProducts : Product
    {
        public DateTime ExpireDate { get; set; }
    }

    class DairyProducts : ExpirableProducts
    {
        public float FatRate { get; set; }
    }

    class Client
    {
        public string SerialNumber { get; set; }
        public string Firstname { get; set; }
        public string Lastname { get; set; }

        private string _phone;
        public string Phone
        {
            get { return _phone; }
            set {
                Regex regex = new Regex(@"(\+994) (50|51|55|70|77)-? *[2-9]{1}\d{2}-? *-?\d{4}");

                if (!regex.IsMatch(value))
                {
                    throw new ArgumentException("Phone number is not valid");
                }
                _phone = value;
            }
        }
    }

    class Person
    {
        //auto property
        //private string _firstname;
        //public string Firstname {
        //    get { return _firstname; }
        //    set
        //    {
        //        if(value.Trim().Length <= 2)
        //        {
        //            throw new ArgumentException("Firstname should be more than 2 characters");
        //        }

        //        _firstname = value.Trim();
        //    }
        //}
        //public string Lastname { get; set; }
        //public DateTime Birthdate { get; set; }

        //public Person()
        //{
        //    Console.WriteLine("New person just was born");
        //}

        //public Person(string firstname)
        //{
        //    Firstname = firstname;
        //    Console.WriteLine("Second ctor");
        //}

        //public Person(string fname, DateTime birthdate) : this(fname)
        //{
        //    Birthdate = birthdate;
        //    Console.WriteLine("Third ctor");
        //}
    }
}
